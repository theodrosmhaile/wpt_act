%% Reformat WPT data for analysis
%
%   Import data for each participant
num_ID = 1; prob = 2; freq = 3; pat_ID = 4; co = 5; Lseq = 6;
trial_id = 7;
exp = '[0-9]'; %regular expression for isolating ID numbers
%Path = '/Users/ccdl/OneDrive - UW/UW/Learning_Strategies/Analysis/WPT';
Path = '/Volumes/GoogleDrive/My Drive/CCDL Shared/Shared/Teddy/winter_19_subjectpool_data/raw/WPT';

Thesefiles = dir([Path,'/*62*record*.mat']);%This pattern finds the 6200+ subject pool data
  
header = {'subject','pattern','pat_prblty','cue1','cue2','cue3','cue4',...
       'start_time','RT','trial_outcome','response','accuracy'};
   
   TempFile = []; 
  
for n = 1: length(Thesefiles)
    %Read in matfile
    load([Path,'/',Thesefiles(n).name]); 
    Pattern{co}(isnan(Pattern{co}))=-1; %#ok<*SAGROW> %set nans for chance outcome to -1
   
    TempFile = [TempFile ;... vertical concatenation
       ones(200,1) * str2double( Thesefiles(n).name(regexp(Thesefiles(n).name,exp)) ),...column1 subject ID
          Pattern{trial_id}, ... column 2: of the 14 patterns,this trial's pattern
          Pattern{Lseq}(Pattern{7}), ...column 3: pre-defined probability of pattern/trial
          Pattern{pat_ID}(Pattern{trial_id},1),...column 4: 1 = cue 1 was present
          Pattern{pat_ID}(Pattern{trial_id},2),...column 5: 1 = cue 2 was present
          Pattern{pat_ID}(Pattern{trial_id},3),...column 6: 1 = cue 3 was present
          Pattern{pat_ID}(Pattern{trial_id},4),...column 7: 1 = cue 4 was present
          ones(200,1) * Record.startTime,... column 8: Start time of first trial
          Record.keypresses',...column 9: reaction time for all key responses responses
          Record.trialOutcome',...column 10: best outcome for trial
          Record.Response',...column 11: subject reponses
          Record.trialOutcome' == Record.Response']; %column 12: calculated correctness 
        
  
 
   clearvars Pattern* Record*
end

tempDataset = mat2dataset(TempFile,'VarNames',header) ;
  tempTable = dataset2table(tempDataset);
  
writetable(tempTable,[Path,'/../../Processed/wpt_n_',num2str(length(Thesefiles)),'_subPool_data_',date,'.txt'])
csvwrite([Path,'/../../Processed/wpt_n_',num2str(length(Thesefiles)),'_subjects_',date,'.csv'],...
    double(unique(tempDataset(:,1))))

% dlmwrite([Path,'/../Processed/wpt_n17_0118_data.txt'],...
%        tempTable,'delimiter',',','precision',10)
 
